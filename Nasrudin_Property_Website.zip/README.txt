NASRUDIN PROPERTY - Website Fase 1

Cara menggunakan:
1. Buka index.html di browser untuk melihat website.
2. Untuk mengganti/menambah properti, buka index.html dengan editor teks dan ubah data pada bagian `const properties=[...]`.
3. Ganti teks FOTO PROPERTI dengan gambar asli pada tahap berikutnya.
4. Nomor WhatsApp saat ini memakai nomor yang diberikan sebelumnya: 081388311676.
5. Website ini adalah versi awal statis. Tahap berikutnya dapat dibuat menjadi marketplace dengan database, login agen, dashboard admin, upload foto, dan pembayaran.

Catatan:
- Desain responsif untuk HP dan desktop.
- Tombol WhatsApp sudah aktif.
- Pencarian, filter status, filter tipe, dan detail properti sudah berfungsi.
